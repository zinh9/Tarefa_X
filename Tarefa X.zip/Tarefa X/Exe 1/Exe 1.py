from mostrar_pares import pares

if __name__ == '__main__':
    lista_numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    pares(lista_numeros)