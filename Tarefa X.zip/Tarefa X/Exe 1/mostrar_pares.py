def pares(lista_numeros):
    for i in lista_numeros:
        if i % 2 == 0:
            print(i)