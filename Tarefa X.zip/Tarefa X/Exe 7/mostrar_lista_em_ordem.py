def mostrar(lista_nomes):
    for nome in lista_nomes:
        print(nome)