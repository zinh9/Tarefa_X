def ordenar_lista(lista_nomes):
    lista_auxiliar = []
    alfabeto = 'abcdefghijklmnopqrstwxyz'

    for letra in alfabeto:
        for nome in lista_nomes:
            if nome[0] == letra:
                lista_auxiliar.append(nome)
    
    return lista_auxiliar