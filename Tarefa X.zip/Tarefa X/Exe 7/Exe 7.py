from ordem_alfabetica import ordenar_lista
from mostrar_lista_em_ordem import mostrar

if __name__ == '__main__':
    lista_nomes = ['enzo', 'marinana', 'paulo', 'luck', 'han solo']
    lista_nomes = ordenar_lista(lista_nomes)
    mostrar(lista_nomes)