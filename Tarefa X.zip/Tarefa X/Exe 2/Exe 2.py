from palavras_maior_5_letras import maior
from mostrar_nova_lista import mostrar

if __name__ == '__main__':
    lista_palavras = ['arroz', 'feijão', 'beringela', 'baralho', 'dama']
    nova_lista_palavras = maior(lista_palavras)
    mostrar(nova_lista_palavras)