def mostrar(nova_lista_palavras):
    for palavra in nova_lista_palavras:
        print(palavra)