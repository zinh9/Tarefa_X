def maior(lista_palavras):
    nova_lista_palavras = []
    
    for palavra in lista_palavras:
        if len(palavra) >= 5:
            nova_lista_palavras.append(palavra)
    
    return nova_lista_palavras