def adicionar():
    lista_compras = []
    
    while True:
        compra = input('Digite a compra para adicionar na lista (digite "sair" para encerrar): ')

        if compra == 'sair':
            break
        
        lista_compras.append(compra)
    
    return lista_compras