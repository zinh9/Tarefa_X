def mostrar(lista_compras):
    for compra in lista_compras:
        print(compra)