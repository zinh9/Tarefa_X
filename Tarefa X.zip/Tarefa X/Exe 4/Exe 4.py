from colocar_compras import adicionar
from mostrar_compras import mostrar

if __name__ == '__main__':
    lista_compras = adicionar()
    mostrar(lista_compras)