def soma_tudo(lista_numeros):
    soma = sum(lista_numeros)
    print(f'A soma de todos os numeros da lista é {soma}')