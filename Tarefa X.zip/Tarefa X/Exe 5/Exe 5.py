from somar_todos import soma_tudo

if __name__ == '__main__':
    lista_numeros = [3, 5, 6, 87, 4, 3, 2, 7, 9 ]
    soma_tudo(lista_numeros)