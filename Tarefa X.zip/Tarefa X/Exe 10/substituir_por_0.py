def substituir(lista_numeros):
    i = 0
    
    for numero in lista_numeros:
        if numero % 2 == 0:
            lista_numeros[i] = 0
        
        i += 1
    
    return lista_numeros