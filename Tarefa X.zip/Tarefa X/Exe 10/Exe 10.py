from substituir_por_0 import substituir
from mostrar_lista_substituida import mostrar

if __name__ == '__main__':
    lista_numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    lista_numeros = substituir(lista_numeros)
    mostrar(lista_numeros)