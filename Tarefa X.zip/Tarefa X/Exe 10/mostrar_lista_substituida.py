def mostrar(lista_numeros):
    for numero in lista_numeros:
        print(numero)