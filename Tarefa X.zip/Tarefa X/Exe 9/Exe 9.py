from verificar_algo_comum import verificar

if __name__ == '__main__':
    lista_1 = [10, True, "enzo", 3.7, "sla", False, 100]
    lista_2 = [1, False, "mari", 3.7, "sla", True, 99]
    verificar(lista_1, lista_2)