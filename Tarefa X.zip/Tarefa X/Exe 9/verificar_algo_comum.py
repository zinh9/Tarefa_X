def verificar(lista_1, lista_2):
    for algo in lista_1:
        if algo in lista_2:
            print(f'Tem algo em comum: {algo}')