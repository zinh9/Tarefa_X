from remover_numeros_duplicados import remover_duplicados
from mostrar_lista_certa import mostrar

if __name__ == '__main__':
    lista_numeros = [1, 1, 2, 3, 4, 4, 5, 6, 7, 7, 8, 8, 9, 9, 10]
    lista_numeros = remover_duplicados(lista_numeros)
    mostrar(lista_numeros)