def remover_duplicados(lista_numeros):
    i = 0
    j = 1

    while j < len(lista_numeros) - 1:
        if lista_numeros[i] == lista_numeros[j]:
            lista_numeros.remove(lista_numeros[j])
        
        i += 1
        j += 1
    
    return lista_numeros