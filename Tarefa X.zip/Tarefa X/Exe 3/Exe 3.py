from inverter_ordem import inverter
from mostrar_lista_invertida import mostrar

if __name__ == '__main__':
    lista_numeros = [1, 2, 3, 4, 5]
    lista_numeros = inverter(lista_numeros)
    mostrar(lista_numeros)