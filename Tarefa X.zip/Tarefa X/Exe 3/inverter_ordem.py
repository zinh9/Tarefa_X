def inverter(lista_numeros):
    lista_auxiliar = []
    i = len(lista_numeros) - 1

    while i >= 0:
        lista_auxiliar.append(lista_numeros[i])

        i -= 1
    
    return lista_auxiliar