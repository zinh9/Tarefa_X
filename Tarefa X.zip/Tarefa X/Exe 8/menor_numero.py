def menor(lista_numeros):
    menor = 0

    for numero in lista_numeros:
        if menor > numero:
            menor = numero
    
    print(f'O menor numero é {menor}')