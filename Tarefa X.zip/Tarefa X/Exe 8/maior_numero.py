def maior(lista_numeros):
    maior = 0

    for numero in lista_numeros:
        if numero > maior:
            maior = numero
    
    print(f'O maior numero é {maior}')
    