from maior_numero import maior
from menor_numero import menor

if __name__ == '__main__':
    lista_numeros = [1, 6, 4, 9, 10, 35, 6, 34, 0]
    maior(lista_numeros)
    menor(lista_numeros)